# DebounceInput
This is a library for the Arduino IDE for debouncing digital inputs (buttons, switches).

For information (installation, usage), [see the wiki](https://github.com/PaulMurrayCbr/DebounceInput/wiki). 
